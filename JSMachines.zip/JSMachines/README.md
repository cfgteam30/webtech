# JSMachines

[JSMachines](https://yinonburgansky.github.io/JSMachines/) from [sourceforge](https://sourceforge.net/projects/jsmachines/) fixed on [Github](https://github.com/yinonburgansky/JSMachines/)

## Algorithms

- [ll1](https://yinonburgansky.github.io/JSMachines/ll1.html)
- [slr](https://yinonburgansky.github.io/JSMachines/slr.html)
- [lalr1](https://yinonburgansky.github.io/JSMachines/lalr1.html)
- [lr1](https://yinonburgansky.github.io/JSMachines/lr1.html)
- [turing](https://yinonburgansky.github.io/JSMachines/turing.html)